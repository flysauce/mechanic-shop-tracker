author: Ryan Lubin
purpose: Assignment 1 COMP 2404
source/header/data files: stdio.h, string.h
program: this program keeps a database of customers and their vehicles

gcc -Wall -o assignment1 assignment1.c

./assignment1